package com.ps.projectSekaiDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectSekaiDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
